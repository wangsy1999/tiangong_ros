#include "bitbot_kernel/kernel/kernel_data.hpp"
#include "bitbot_kernel/utils/logger.h"
#include "bitbot_kernel/types.hpp"

//#include "glaze/glaze.hpp"
#include "nlohmann/json.hpp"
#include "readerwriterqueue.h"

#include <fstream>
#include <thread>
#include <map>
#include <unordered_map>
#include <atomic>
#include <optional>

namespace bitbot
{
    using Json = nlohmann::json;
    class Backend
    {
    public:
        Backend(int listen_port = 12888);
        ~Backend();

        void SetPort(int port);
        void RegisterSettingsFile(std::string file);

        void SetMonitorHeaders(std::string json_str);
        void SetMonitorData(const std::vector<Number>& data);

        void SetStatesList(std::vector<std::pair<StateId, std::string>> states);
        void SetEventsMap(std::unordered_map<std::string, EventId>* events_map);

        inline bool GetEvent(std::vector<std::pair<EventId, EventValue>>& event)
        {
            return events_queue_.try_dequeue(event);
        }

        void Run();

        void Stop();

    private:
        void Running();

        void UpdateData();

        struct PerSocketData {
            /* Fill with user data */
        };

    public:
        struct WebsocketMessageType
        {
            std::string type; // message type "request_data" "events" "monitor_data"
            std::string data; // message data
        };

        struct MonitorData
        {
            std::vector<Number> data;
        };

        struct BackendControlSetting
        {
            std::string event;
            std::string kb_key;
        };

        struct BackendSettings
        {
            std::vector<BackendControlSetting> control;
        };

        struct EventType
        {
            std::string name;
            EventValue value;
        };

        struct EventsType
        {
            std::vector<EventType> events;
        };

        struct StateType
        {
            StateId id;
            std::string name;
        };

        struct StatesType
        {
            std::vector<StateType> states;
        };

    private:
        Logger::Console logger_;

        bool run_ = false;
        int listen_port_;
        BackendSettings settings_;

        std::string monitor_headers_json_;
        std::atomic<bool> is_data_update_ = false;
        std::atomic<bool> is_reading_data_ = false;
        MonitorData monitor_data_;
        std::string monitor_data_str_;

        StatesType states_list_;
        std::string states_list_str_;

        std::unordered_map<std::string, EventId>* events_name_id_map_ = nullptr;

        moodycamel::ReaderWriterQueue<std::vector<std::pair<EventId, EventValue>>> events_queue_;

        std::unique_ptr<std::thread> running_thread_ = nullptr;
    };

    void to_json(Json& j, const Backend::WebsocketMessageType& data);
    void to_json(Json& j, const Backend::MonitorData& data);
    void to_json(Json& j, const Backend::BackendControlSetting& data);
    void to_json(Json& j, const Backend::BackendSettings& data);
    void to_json(Json& j, const Backend::EventType& data);
    void to_json(Json& j, const Backend::EventsType& data);
    void to_json(Json& j, const Backend::StateType& data);
    void to_json(Json& j, const Backend::StatesType& data);

    void from_json(Json& j, Backend::WebsocketMessageType& data);
    void from_json(Json& j, Backend::MonitorData& data);
    void from_json(Json& j, Backend::BackendControlSetting& data);
    void from_json(Json& j, Backend::BackendSettings& data);
    void from_json(Json& j, Backend::EventType& data);
    void from_json(Json& j, Backend::EventsType& data);
    void from_json(Json& j, Backend::StateType& data);
    void from_json(Json& j, Backend::StatesType& data);
}


