#include "bitbot_kernel/kernel/backend.h"
#include "bitbot_kernel/utils/time_func.h"
#include "bitbot_kernel/utils/assert.h"
#include "nlohmann/json.hpp"
#include "App.h"

namespace bitbot
{
  namespace {
    uWS::Loop* uws_loop;
    std::unique_ptr<uWS::App> uws_app;
  }

  Backend::Backend(int listen_port)
    : logger_(Logger().ConsoleLogger())
    , listen_port_(listen_port)
    , events_queue_(16)
    , running_thread_(nullptr)
  {
    WebsocketMessageType aaa;
    Json aj{ aaa };

  }

  Backend::~Backend()
  {
    Stop();
  }

  void Backend::SetPort(int port)
  {
    listen_port_ = port;
  }

  void Backend::RegisterSettingsFile(std::string file)
  {
    // auto buffer = glz::file_to_buffer(file);
    // auto ec = glz::read<glz::opts{.error_on_unknown_keys = false}>(settings_, buffer);
    // if (ec) {
    //   logger_->error(glz::format_error(ec, buffer));
    // }

    //read file to json
    std::ifstream ifs(file);
    Json j = Json::parse(ifs);
    ifs.close();
    //std::cout << "settings: " << j.dump() << std::endl;
    from_json(j, settings_);
    //std::cout << this->settings_.control.size() << std::endl;
    // for (auto& control : settings_.control)
    // {
    //   std::cout << control.event << ", " << control.kb_key << std::endl;
    // }
  }

  void Backend::SetMonitorHeaders(std::string str)
  {
    monitor_headers_json_ = str;
    //std::cout << "monitor headers: " << monitor_headers_json_ << std::endl;
  }

  void Backend::SetStatesList(std::vector<std::pair<StateId, std::string>> states)
  {
    for (auto& state : states)
    {
      states_list_.states.push_back({ .id = state.first, .name = state.second });
    }
    Json j{ states_list_ };
    states_list_str_ = j.dump();
    //std::cout << "states list: " << states_list_str_ << std::endl;
  }

  void Backend::SetEventsMap(std::unordered_map<std::string, EventId>* events_map)
  {
    events_name_id_map_ = events_map;
  }

  void Backend::Run()
  {
    if (!run_)
    {
      bitbot_assert(events_name_id_map_, "Backend events_name_id_map_ must have valid value");
      if (running_thread_ == nullptr)
        running_thread_ = std::make_unique<std::thread>(&Backend::Running, this);

      run_ = true;
    }
  }

  void Backend::Stop()
  {
    if (uws_app && run_)
    {
      uws_loop->defer([this]() {
        uws_app->close();
        uws_app = nullptr;
        });
      if (running_thread_->joinable())
      {
        running_thread_->join();
        running_thread_ = nullptr;
      }
      run_ = false;
    }
  }

  void Backend::SetMonitorData(const std::vector<Number>& data)
  {
    if (!is_reading_data_.load())
    {
      is_reading_data_.store(true);
      monitor_data_.data = data;
      is_reading_data_.store(false);
      is_data_update_.store(true);
    }
  }

  void Backend::Running()
  {
    uws_app = std::make_unique<uWS::App>();
    uws_app->get("/monitor/headers", [this](auto* res, auto*/*req*/) {
      // std::cout << "http req from " << res->getRemoteAddressAsText() << std::endl;
      res->writeHeader("Access-Control-Allow-Origin", "*");
      res->writeHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
      res->writeHeader("Access-Control-Allow-Headers", "origin, content-type, accept, x-requested-with");
      res->writeHeader("Access-Control-Max-Age", "3600");
      res->end(this->monitor_headers_json_);
      }).get("/monitor/stateslist", [this](auto* res, auto*/*req*/) {
        // std::cout << "http req from " << res->getRemoteAddressAsText() << std::endl;
        res->writeHeader("Access-Control-Allow-Origin", "*");
        res->writeHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res->writeHeader("Access-Control-Allow-Headers", "origin, content-type, accept, x-requested-with");
        res->writeHeader("Access-Control-Max-Age", "3600");
        res->end(this->states_list_str_);
        }).get("/setting/control/get", [this](auto* res, auto*/*req*/) {
          // std::cout << "http setting/get req from " << res->getRemoteAddressAsText() << std::endl;
          res->writeHeader("Access-Control-Allow-Origin", "*");
          res->writeHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
          res->writeHeader("Access-Control-Allow-Headers", "origin, content-type, accept, x-requested-with");
          res->writeHeader("Access-Control-Max-Age", "3600");
          std::string json_str;
          Json j;
          to_json(j, settings_.control);

          json_str = j.dump();
          //std::cout << "ctrl:" << json_str << std::endl;
          res->end(json_str);
          //res->end(glz::write_json(settings_.control));
          }).ws<PerSocketData>("/console", {
            /* Settings */
            .compression = uWS::CompressOptions(uWS::DEDICATED_COMPRESSOR_4KB | uWS::DEDICATED_DECOMPRESSOR),
            .maxPayloadLength = 100 * 1024 * 1024,
            .idleTimeout = 16,
            .maxBackpressure = 100 * 1024 * 1024,
            .closeOnBackpressureLimit = false,
            .resetIdleTimeoutOnSend = false,
            .sendPingsAutomatically = true,
            /* Handlers */
            .upgrade = nullptr,
            .open = [this](auto*/*ws*/) {
              /* Open event here, you may access ws->getUserData() which points to a PerSocketData struct */

            // std::cout << "A data WebSocket connected! " << ws->getRemoteAddressAsText() << std::endl;
          },
          .message = [this](auto* ws, std::string_view message, uWS::OpCode /*opCode*/) {
            static WebsocketMessageType msg_send;
            static WebsocketMessageType msg_receive;
            // logger_->debug("console message: {}", message);

            //auto ec = glz::read<glz::opts{.error_on_unknown_keys = false}>(msg_receive, message);
            Json j = Json::parse(message);
            from_json(j, msg_receive);
            auto ec = false;
            if (ec)
            {
              //logger_->error(glz::format_error(ec, message));
            }
            else
            {
              if (msg_receive.type.compare("request_data") == 0)
              {
                UpdateData();
                msg_send.type = "monitor_data";
                msg_send.data = monitor_data_str_;
                Json j;
                to_json(j, msg_send);
                ws->send(j.dump(), uWS::TEXT, true);
                //ws->send(glz::write_json(msg_send), uWS::TEXT, true);
              }
              else if (msg_receive.type.compare("events") == 0)
              {
                EventsType events;
                //ec = glz::read<glz::opts{.error_on_unknown_keys = false}>(events, msg_receive.data);
                Json j = Json::parse(msg_receive.data);
                from_json(j, events);
                ec = false;
                if (ec)
                {
                  //logger_->error(glz::format_error(ec, msg_receive.data));
                }
                else
                {
                  if (!events.events.empty())
                  {
                    std::vector<std::pair<std::string,EventValue>> cmds;
                    std::vector<std::pair<EventId, EventValue>> temp_events;
                    for (auto& event : events.events)
                    {
                      cmds.push_back(std::pair<std::string,int>(event.name,event.value));
                      if (auto i = events_name_id_map_->find(event.name); i != events_name_id_map_->end())
                      {
                        temp_events.push_back(std::pair<EventId, EventValue>(i->second, event.value));
                      }
                    }
                    events_queue_.enqueue(temp_events);
                  }
                }
              }
            }
          },
          .drain = [](auto*/*ws*/) {
              /* Check ws->getBufferedAmount() here */
          },
          .ping = [](auto*/*ws*/, std::string_view) {
              /* Not implemented yet */
          },
          .pong = [](auto*/*ws*/, std::string_view) {
              /* Not implemented yet */
          },
          .close = [](auto*/*ws*/, int /*code*/, std::string_view /*message*/) {
              /* You may access ws->getUserData() here */

            // std::cout << "ws console Connection closed" << std::endl;
          }
            }).listen(listen_port_, [this](auto* socket) {
              if (socket)
              {
                logger_->info("Backend is listening on port {}", this->listen_port_);
                uws_loop = uWS::Loop::get();
              }
              else
              {
                logger_->error("Backend failed to listen on port {}", this->listen_port_);
              }
              }).run();
  }

  void Backend::UpdateData()
  {
    if (is_data_update_.load())
    {
      is_reading_data_.store(true);
      Json j;
      to_json(j, monitor_data_);
      monitor_data_str_ = j.dump();
      is_reading_data_.store(false);
      is_data_update_.store(false);
    }
  }

  void to_json(Json& j, const Backend::WebsocketMessageType& data)
  {
    j = Json{ {"type",data.type},{"data",data.data} };
  }

  void to_json(Json& j, const Backend::MonitorData& data)
  {
    Json json = Json::array();
    for (auto& d : data.data)
    {
      std::visit([&json](auto&& arg) {

        json.push_back(arg); }, d);
    }
    j = Json{ {"data",json} };
  }

  void to_json(Json& j, const Backend::BackendControlSetting& data)
  {
    j = Json{ {"event",data.event},{"kb_key",data.kb_key} };
  }

  void to_json(Json& j, const Backend::BackendSettings& data)
  {
    j = Json{ "control",data.control };
  }

  void to_json(Json& j, const Backend::EventType& data)
  {
    j = Json{ {"name",data.name},{"value",data.value} };
  }

  void to_json(Json& j, const Backend::EventsType& data)
  {
    j = Json{ "events",data.events };
  }

  void to_json(Json& j, const Backend::StateType& data)
  {
    j = Json{ {"id",data.id},{"name",data.name} };
  }

  void to_json(Json& j, const Backend::StatesType& data)
  {
    j = Json{ "states",data.states };
  }


  void from_json(Json& j, Backend::WebsocketMessageType& data)
  {
    j.at("type").get_to(data.type);
    j.at("data").get_to(data.data);
  }

  void from_json(Json& j, Backend::MonitorData& data)
  {
    Json json = j.at("data");
    for (Json::iterator it = json.begin(); it != json.end(); ++it)
    {
      Number number;
      if (it->is_number_integer())
        number = it->get<uint64_t>();
      else if (it->is_number_float())
        number = it->get<double>();
      data.data.push_back(number);
    }
  }

  void from_json(Json& j, Backend::BackendControlSetting& data)
  {
    j.at("event").get_to(data.event);
    j.at("kb_key").get_to(data.kb_key);
  }

  void from_json(Json& j, Backend::BackendSettings& data)
  {
    //use iterator to get all the elements in the json
    Json json = j.at("control");
    for (Json::iterator it = json.begin(); it != json.end(); ++it)
    {
      Backend::BackendControlSetting setting;
      from_json(it.value(), setting);
      data.control.push_back(setting);
    }
  }

  void from_json(Json& j, Backend::EventType& data)
  {
    j.at("name").get_to(data.name);
    j.at("value").get_to(data.value);
  }

  void from_json(Json& j, Backend::EventsType& data)
  {
    Json json = j.at("events");
    for (Json::iterator it = json.begin(); it != json.end(); ++it)
    {
      Backend::EventType event;
      from_json(it.value(), event);
      data.events.push_back(event);
    }
  }

  void from_json(Json& j, Backend::StateType& data)
  {
    j.at("id").get_to(data.id);
    j.at("name").get_to(data.name);
  }

  void from_json(Json& j, Backend::StatesType& data)
  {
    Json json = j.at("states");
    for (Json::iterator it = json.begin(); it != json.end(); ++it)
    {
      Backend::StateType state;
      from_json(it.value(), state);
      data.states.push_back(state);
    }
  }

}
