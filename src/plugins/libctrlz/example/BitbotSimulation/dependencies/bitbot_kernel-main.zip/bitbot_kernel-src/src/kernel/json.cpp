#include "nlohmann/json.hpp"

#include "bitbot_kernel/device/device.hpp"
#include "bitbot_kernel/bus/bus_manager.hpp"

namespace bitbot
{
    void to_json(Json& j, const DeviceMonitorHeader& data)
    {
        j = Json{ {"name",data.name},{"type",data.type},{"headers",data.headers} };
    }
    void from_json(Json& j, DeviceMonitorHeader& data)
    {
        j.at("name").get_to(data.name);
        j.at("type").get_to(data.type);
        j.at("headers").get_to(data.headers);
    }

    void to_json(Json& j, const BusMonitorHeader& data)
    {
        j = Json{ {"devices",data.devices} };
    }
    void from_json(Json& j, BusMonitorHeader& data)
    {
        Json devices = j.at("devices");
        data.devices.clear();
        for (auto& device : devices)
        {
            DeviceMonitorHeader device_monitor_header;
            to_json(device, device_monitor_header);
            data.devices.push_back(device_monitor_header);
        }
    }
};

