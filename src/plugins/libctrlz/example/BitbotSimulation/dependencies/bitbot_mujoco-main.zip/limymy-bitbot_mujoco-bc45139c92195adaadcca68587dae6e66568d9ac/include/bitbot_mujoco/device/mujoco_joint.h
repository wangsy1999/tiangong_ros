﻿#pragma once

#include "bitbot_mujoco/device/mujoco_device.hpp"
#include <array>
#include <map>
#include <optional>

namespace bitbot
{
  enum class MujocoJointMode
  {
    NONE = 0,
    POSITION,
    VELOCITY,
    TORQUE
  };

  class MujocoJoint final: public MujocoDevice
  {
  public:
    MujocoJoint(const pugi::xml_node& device_node);
    ~MujocoJoint();

    static std::string ModeToStr(const MujocoJointMode& mode);

    static MujocoJointMode ModeFromStr(const std::string& mode);

    inline double GetActualPosition()
    {
      return actual_position_;
    }

    inline double GetActualVelocity()
    {
      return actual_velocity_;
    }

    inline double GetActualTorque()
    {
      return actual_torque_;
    }

    inline void SetTargetPosition(double pos)
    {
      target_position_ = pos;
    }

    inline void SetTargetVelocity(double vel)
    {
      target_velocity_ = vel;
    }

    inline void SetTargetTorque(double torque)
    {
      target_torque_ = torque;
    }

    inline void SetMode(MujocoJointMode mode)
    {
      if(mode_ != MujocoJointMode::POSITION)
        pos_i_ = 0;
      mode_ = mode;
    }

  private:
    virtual void UpdateModel(const mjModel*m, mjData* mj_d);
    virtual void Input(const mjModel*m, mjData* mj_d) final;
    virtual void Output(const mjModel*m, mjData* mj_d) final;

    virtual void UpdateRuntimeData() final;

    bool enable_ = true;
    int mj_joint_id_ = 0;
    int mj_jointqpos_adr_ = 0;
    int mj_jointqvel_adr_ = 0;
    int mj_actuator_id_ = 0;
    int mj_actuatorforce_adr_ = 0;

    int mj_joint_type_ = mjJNT_HINGE;
    double initial_pos_ = 0;

    MujocoJointMode mode_;
    double actual_position_ = 0;
    double actual_velocity_ = 0;
    double actual_torque_ = 0;
    double target_position_ = 0;
    double target_velocity_ = 0;
    double target_torque_ = 0;

    double pos_i_ = 0; // 位控积分值
    double pos_kp_ = 100;
    double pos_kd_ = 50;
    double pos_ki_ = 10;

    double vel_i_ = 0; // 速度控制积分值
    double vel_kp_ = 100;
    double vel_kd_ = 50;
    double vel_ki_ = 10;
  };


}

